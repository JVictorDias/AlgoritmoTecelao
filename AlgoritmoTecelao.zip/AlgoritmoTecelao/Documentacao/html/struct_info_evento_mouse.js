var struct_info_evento_mouse =
[
    [ "acao", "struct_info_evento_mouse.html#ad7f671871e99cdf07f97329a5c3ac3d5", null ],
    [ "botao", "struct_info_evento_mouse.html#a1172176a50f9cbb386c68d95f02f4c4d", null ],
    [ "posX", "struct_info_evento_mouse.html#a33b5db5f4c31765c0530754fed4c0303", null ],
    [ "posY", "struct_info_evento_mouse.html#af33a4a28bb319e7665bc62c9e8cbdec6", null ],
    [ "relX", "struct_info_evento_mouse.html#a3853c91166bcea99068ca4544b6001d6", null ],
    [ "relY", "struct_info_evento_mouse.html#abacbbe2dc55ab39769344176a925ea27", null ]
];