var struct_info_evento_janela =
[
    [ "acao", "struct_info_evento_janela.html#add917a545c6352dccd69e6988caff486", null ],
    [ "dado1", "struct_info_evento_janela.html#a8dc386581586a2cb197b8351129b8440", null ],
    [ "dado2", "struct_info_evento_janela.html#a2357b0ff09d5e54b73f56fde2c624cbd", null ]
];