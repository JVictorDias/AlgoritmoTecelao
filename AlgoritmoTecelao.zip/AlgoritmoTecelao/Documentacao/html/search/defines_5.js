var searchData=
[
  ['janela_5falterada',['JANELA_ALTERADA',['../_tipos___p_i_g_8h.html#ae1cf91bd316ef9bbbfe3145ba11a95dd',1,'Tipos_PIG.h']]],
  ['janela_5fexibida',['JANELA_EXIBIDA',['../_tipos___p_i_g_8h.html#a58532b0c46f6e312d7197cc39347247d',1,'Tipos_PIG.h']]],
  ['janela_5fexposta',['JANELA_EXPOSTA',['../_tipos___p_i_g_8h.html#a0b5bb4d9296e386f970cd85305ff12a8',1,'Tipos_PIG.h']]],
  ['janela_5ffechada',['JANELA_FECHADA',['../_tipos___p_i_g_8h.html#a179ca9079c1dc85da48cffcce4f5316a',1,'Tipos_PIG.h']]],
  ['janela_5fganhofoco',['JANELA_GANHOFOCO',['../_tipos___p_i_g_8h.html#a0b89e757b505cabcf333c9510e41a799',1,'Tipos_PIG.h']]],
  ['janela_5fmaximizada',['JANELA_MAXIMIZADA',['../_tipos___p_i_g_8h.html#a638d038a0a8b117ec53dd0d3d08c5567',1,'Tipos_PIG.h']]],
  ['janela_5fminimizada',['JANELA_MINIMIZADA',['../_tipos___p_i_g_8h.html#a97cb1c91cbfd7645c38920e732f62f54',1,'Tipos_PIG.h']]],
  ['janela_5fmousedentro',['JANELA_MOUSEDENTRO',['../_tipos___p_i_g_8h.html#a33801daa166775719ff2cd60a93114ef',1,'Tipos_PIG.h']]],
  ['janela_5fmousefora',['JANELA_MOUSEFORA',['../_tipos___p_i_g_8h.html#aa18b1f3f3fc21fde98cfe9f3f3a323ef',1,'Tipos_PIG.h']]],
  ['janela_5fmovida',['JANELA_MOVIDA',['../_tipos___p_i_g_8h.html#aaef0707f208e82b5c17189b5a090b86b',1,'Tipos_PIG.h']]],
  ['janela_5foculta',['JANELA_OCULTA',['../_tipos___p_i_g_8h.html#a4433d386efdf9a93e098339778fcca48',1,'Tipos_PIG.h']]],
  ['janela_5fperdafoco',['JANELA_PERDAFOCO',['../_tipos___p_i_g_8h.html#a2e617008622565c6d0436dfaef9ae137',1,'Tipos_PIG.h']]],
  ['janela_5fredimensionada',['JANELA_REDIMENSIONADA',['../_tipos___p_i_g_8h.html#aa891486ecf4dae319a02ff46cd994d39',1,'Tipos_PIG.h']]],
  ['janela_5frestaurada',['JANELA_RESTAURADA',['../_tipos___p_i_g_8h.html#ac3e35c7dfebdab1f2ec6a27cce7b0917',1,'Tipos_PIG.h']]]
];
