var searchData=
[
  ['calculalargurapixels',['CalculaLarguraPixels',['../_p_i_g_8h.html#a6fc14f5a21760365319ba7cc02b58161',1,'PIG.h']]],
  ['carregacursor',['CarregaCursor',['../_p_i_g_8h.html#af39699fa8fff4392a3e45ca7fb1319d3',1,'PIG.h']]],
  ['colisaoanimacaoobjeto',['ColisaoAnimacaoObjeto',['../_p_i_g_8h.html#ab556d15da5181de2531ddadfece65b4c',1,'PIG.h']]],
  ['colisaoanimacoes',['ColisaoAnimacoes',['../_p_i_g_8h.html#a3250227c2ef653563a12e02f50a51bcb',1,'PIG.h']]],
  ['colisaoparticulasanimacao',['ColisaoParticulasAnimacao',['../_p_i_g_8h.html#ac091c556dd989bb121bb9cb5c4b8ab2b',1,'PIG.h']]],
  ['colisaoparticulasobjeto',['ColisaoParticulasObjeto',['../_p_i_g_8h.html#afa627d8dbfd184a3b0979175471e1893',1,'PIG.h']]],
  ['criaanimacao',['CriaAnimacao',['../_p_i_g_8h.html#ab908f3118f338cda3c31bb62f7c1cc99',1,'CriaAnimacao(char *nomeArquivo, int retiraFundo=1, int opacidade=255):&#160;PIG.h'],['../_p_i_g_8h.html#adc6cd6c581370fcb0cc02d77d44452b8',1,'CriaAnimacao(int id_animacao):&#160;PIG.h']]],
  ['criafontefundo',['CriaFonteFundo',['../_p_i_g_8h.html#abc69aebeee3cbb9e67321d6530438d2e',1,'PIG.h']]],
  ['criafontenormal',['CriaFonteNormal',['../_p_i_g_8h.html#a3c0b3bd89063e54459ee19515e1131e4',1,'PIG.h']]],
  ['criaframeanimacao',['CriaFrameAnimacao',['../_p_i_g_8h.html#a5b9bf47981b2627e5ad7c4184e9b07fa',1,'PIG.h']]],
  ['criageradorparticulas',['CriaGeradorParticulas',['../_p_i_g_8h.html#a614f87c3aa5f59ba80bf8188c27371e4',1,'PIG.h']]],
  ['criajogo',['CriaJogo',['../_p_i_g_8h.html#ad7af2ee787e64c8a7e4da35ae1bab2b2',1,'PIG.h']]],
  ['criamodoanimacao',['CriaModoAnimacao',['../_p_i_g_8h.html#a288bda95429478463dc3d07b9f514334',1,'PIG.h']]],
  ['criaobjeto',['CriaObjeto',['../_p_i_g_8h.html#a56a1cce709bdbfe6ff342b3884046142',1,'PIG.h']]],
  ['criaparticula',['CriaParticula',['../_p_i_g_8h.html#af947d17d965122595ff68a177e7768a7',1,'PIG.h']]],
  ['criatimer',['CriaTimer',['../_p_i_g_8h.html#a7bb67017642c68edecc1e3c1a4d28a2e',1,'PIG.h']]]
];
