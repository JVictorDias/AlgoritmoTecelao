var searchData=
[
  ['reiniciatimer',['ReiniciaTimer',['../_p_i_g_8h.html#a6e06927682fe71ad4baa7e2ade66f2e4',1,'PIG.h']]],
  ['relx',['relX',['../struct_info_evento_mouse.html#a3853c91166bcea99068ca4544b6001d6',1,'InfoEventoMouse']]],
  ['rely',['relY',['../struct_info_evento_mouse.html#abacbbe2dc55ab39769344176a925ea27',1,'InfoEventoMouse']]],
  ['repeticao',['repeticao',['../struct_info_evento_teclado.html#a2ebbbeef2bac0adeef90b29b6274720f',1,'InfoEventoTeclado']]],
  ['roxo',['ROXO',['../_tipos___p_i_g_8h.html#a40aa83ddba5d06d1eeb7155b1d2d4753',1,'Tipos_PIG.h']]]
];
