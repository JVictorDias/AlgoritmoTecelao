var searchData=
[
  ['infoeventojanela',['InfoEventoJanela',['../struct_info_evento_janela.html',1,'']]],
  ['infoeventomouse',['InfoEventoMouse',['../struct_info_evento_mouse.html',1,'']]],
  ['infoeventoteclado',['InfoEventoTeclado',['../struct_info_evento_teclado.html',1,'']]]
];
