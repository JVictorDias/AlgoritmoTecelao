var searchData=
[
  ['iniciadesenho',['IniciaDesenho',['../_p_i_g_8h.html#a12e11bc7373195aca22d8dad38f83e20',1,'PIG.h']]],
  ['insereframeanimacao',['InsereFrameAnimacao',['../_p_i_g_8h.html#a74a31ea83c1a97e16a5e3c046d17026d',1,'PIG.h']]]
];
