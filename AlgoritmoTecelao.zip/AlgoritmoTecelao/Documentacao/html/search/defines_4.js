var searchData=
[
  ['flip_5fhoriz_5fvert',['FLIP_HORIZ_VERT',['../_tipos___p_i_g_8h.html#a5583006c0e7ff072f0a1f95e45c6863d',1,'Tipos_PIG.h']]],
  ['flip_5fhorizontal',['FLIP_HORIZONTAL',['../_tipos___p_i_g_8h.html#a171b02288e1a014931d0fb89bb66083a',1,'Tipos_PIG.h']]],
  ['flip_5fnenhum',['FLIP_NENHUM',['../_tipos___p_i_g_8h.html#a4aed97966bb1ec335028caa24bf7d4cc',1,'Tipos_PIG.h']]],
  ['flip_5fvertical',['FLIP_VERTICAL',['../_tipos___p_i_g_8h.html#ad131a1eae643167036846e8f258697cd',1,'Tipos_PIG.h']]]
];
