var searchData=
[
  ['alt_5ftela',['ALT_TELA',['../_tipos___p_i_g_8h.html#a1e9b38d998b31c626320cd5e62e68fd2',1,'Tipos_PIG.h']]],
  ['amarelo',['AMARELO',['../_tipos___p_i_g_8h.html#abf22a4fcddc9121a35158f974493f881',1,'Tipos_PIG.h']]],
  ['azul',['AZUL',['../_tipos___p_i_g_8h.html#a417a0e2cb13684627c838b16cc69651a',1,'Tipos_PIG.h']]]
];
