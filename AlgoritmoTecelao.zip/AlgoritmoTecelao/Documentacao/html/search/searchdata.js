var indexSectionsWithContent =
{
  0: "acdefgijmpqrst",
  1: "p",
  2: "acdefgijmpqrst",
  3: "j"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Arquivos",
  2: "Funções",
  3: "Variáveis"
};

