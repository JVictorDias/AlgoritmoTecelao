var searchData=
[
  ['relx',['relX',['../struct_info_evento_mouse.html#a3853c91166bcea99068ca4544b6001d6',1,'InfoEventoMouse']]],
  ['rely',['relY',['../struct_info_evento_mouse.html#abacbbe2dc55ab39769344176a925ea27',1,'InfoEventoMouse']]],
  ['repeticao',['repeticao',['../struct_info_evento_teclado.html#a2ebbbeef2bac0adeef90b29b6274720f',1,'InfoEventoTeclado']]]
];
