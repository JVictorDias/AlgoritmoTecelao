var searchData=
[
  ['posx',['posX',['../struct_info_evento_mouse.html#a33b5db5f4c31765c0530754fed4c0303',1,'InfoEventoMouse']]],
  ['posy',['posY',['../struct_info_evento_mouse.html#af33a4a28bb319e7665bc62c9e8cbdec6',1,'InfoEventoMouse']]]
];
