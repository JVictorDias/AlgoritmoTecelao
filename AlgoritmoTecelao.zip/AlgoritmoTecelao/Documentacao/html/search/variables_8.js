var searchData=
[
  ['tamanhoselecao',['tamanhoSelecao',['../struct_info_evento_teclado.html#a1fa842c7b2fefe07ddb2f218899090d7',1,'InfoEventoTeclado']]],
  ['tecla',['tecla',['../struct_info_evento_teclado.html#a5cfdfb147bfd2edfcdafd26e66f4d587',1,'InfoEventoTeclado']]],
  ['teclado',['teclado',['../struct_p_i_g___evento.html#a7657689fcc8188f0cf4c9f8e9c89f7d2',1,'PIG_Evento']]],
  ['texto',['texto',['../struct_info_evento_teclado.html#a8e8399bcf714c54d73e9b4a9375d05e0',1,'InfoEventoTeclado']]],
  ['tipoevento',['tipoEvento',['../struct_p_i_g___evento.html#a0dd3cee5c6ca607a2beb6ff6fff44e81',1,'PIG_Evento']]]
];
