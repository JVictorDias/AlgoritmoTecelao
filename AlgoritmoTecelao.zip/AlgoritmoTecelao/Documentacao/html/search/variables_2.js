var searchData=
[
  ['dado1',['dado1',['../struct_info_evento_janela.html#a8dc386581586a2cb197b8351129b8440',1,'InfoEventoJanela']]],
  ['dado2',['dado2',['../struct_info_evento_janela.html#a2357b0ff09d5e54b73f56fde2c624cbd',1,'InfoEventoJanela']]]
];
