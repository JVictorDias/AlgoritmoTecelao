var searchData=
[
  ['atualizapixelsobjeto',['AtualizaPixelsObjeto',['../_p_i_g_8h.html#a67b416f6a272a10676f1a7decaebabde',1,'PIG.h']]]
];
