var searchData=
[
  ['encerradesenho',['EncerraDesenho',['../_p_i_g_8h.html#a3f591d6270bb3734082e3eb598a0c24a',1,'PIG.h']]],
  ['escrevercentralizada',['EscreverCentralizada',['../_p_i_g_8h.html#a15c934bb47cb5f5dbbc6b2aec96ebb32',1,'PIG.h']]],
  ['escreverdireita',['EscreverDireita',['../_p_i_g_8h.html#a6c89e06962cf66015ac886b2f738ae77',1,'PIG.h']]],
  ['escreveresquerda',['EscreverEsquerda',['../_p_i_g_8h.html#a386b6ac7dc0d4d160e3456e3f17674ce',1,'PIG.h']]],
  ['espera',['Espera',['../_p_i_g_8h.html#a8a79c4d35502283eba439cce9860a22e',1,'PIG.h']]]
];
