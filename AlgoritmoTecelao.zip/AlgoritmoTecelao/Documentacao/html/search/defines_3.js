var searchData=
[
  ['estilo_5fcortado',['ESTILO_CORTADO',['../_tipos___p_i_g_8h.html#a55988b191f39d49b3fb4671330b97ca9',1,'Tipos_PIG.h']]],
  ['estilo_5fitalico',['ESTILO_ITALICO',['../_tipos___p_i_g_8h.html#ac325dd168487cf325fc909965c365cef',1,'Tipos_PIG.h']]],
  ['estilo_5fnegrito',['ESTILO_NEGRITO',['../_tipos___p_i_g_8h.html#a198481d091837f3304ff3204cd8b44c1',1,'Tipos_PIG.h']]],
  ['estilo_5fnormal',['ESTILO_NORMAL',['../_tipos___p_i_g_8h.html#ab6ea9f26f3021e389006ca7443e04623',1,'Tipos_PIG.h']]],
  ['estilo_5fsublinhado',['ESTILO_SUBLINHADO',['../_tipos___p_i_g_8h.html#aec49c9cd8a33e213e1b7e0e28fe16f38',1,'Tipos_PIG.h']]]
];
