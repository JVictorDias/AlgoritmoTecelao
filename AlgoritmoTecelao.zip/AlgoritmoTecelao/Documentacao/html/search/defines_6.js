var searchData=
[
  ['laranja',['LARANJA',['../_tipos___p_i_g_8h.html#aec6988bc93e8b5348e204e5818b2f918',1,'Tipos_PIG.h']]],
  ['larg_5ftela',['LARG_TELA',['../_tipos___p_i_g_8h.html#af23e019e19169e2e6a32ab1ca9739119',1,'Tipos_PIG.h']]]
];
