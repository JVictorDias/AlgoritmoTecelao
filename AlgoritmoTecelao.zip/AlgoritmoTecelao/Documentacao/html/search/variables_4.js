var searchData=
[
  ['janela',['janela',['../struct_p_i_g___evento.html#a608277842dd469ad6e578b3a3515e00a',1,'PIG_Evento']]],
  ['jogo',['jogo',['../_p_i_g_8h.html#add8f6efb79f1188040f7ee0eb9dba65d',1,'PIG.h']]]
];
