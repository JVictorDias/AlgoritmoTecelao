var searchData=
[
  ['nome_5farq_5ftemp',['NOME_ARQ_TEMP',['../_tipos___p_i_g_8h.html#a3ff3f764ee3ea668c0a98cee0337884c',1,'Tipos_PIG.h']]]
];
