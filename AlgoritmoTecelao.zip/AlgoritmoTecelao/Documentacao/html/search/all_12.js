var searchData=
[
  ['verde',['VERDE',['../_tipos___p_i_g_8h.html#a4bb7219220248476df702f5d4fbbb3ab',1,'Tipos_PIG.h']]],
  ['vermelho',['VERMELHO',['../_tipos___p_i_g_8h.html#a9dc6985f34e40c197dc62918a96e3fa7',1,'Tipos_PIG.h']]]
];
