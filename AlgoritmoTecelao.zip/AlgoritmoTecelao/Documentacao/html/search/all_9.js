var searchData=
[
  ['pausatimer',['PausaTimer',['../_p_i_g_8h.html#affc28604e1b2eef4c06eb316653fccac',1,'PIG.h']]],
  ['pausatudo',['PausaTudo',['../_p_i_g_8h.html#a6f5ef37bb352c57cfbbe7690d8e74742',1,'PIG.h']]],
  ['pig_2eh',['PIG.h',['../_p_i_g_8h.html',1,'']]],
  ['pintaareaoffscreen',['PintaAreaOffScreen',['../_p_i_g_8h.html#a573e723cc5b3b528c9e8e9f6bbd4ce78',1,'PIG.h']]],
  ['pintafundooffscreen',['PintaFundoOffScreen',['../_p_i_g_8h.html#a3e885c3fddda2e325b6be42532f001ab',1,'PIG.h']]],
  ['preparaoffscreenrenderer',['PreparaOffScreenRenderer',['../_p_i_g_8h.html#a3017a5f72ff37d15ca4dd0cc2a1a7d6e',1,'PIG.h']]]
];
