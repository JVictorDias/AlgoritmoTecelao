var searchData=
[
  ['infoeventojanela',['InfoEventoJanela',['../_tipos___p_i_g_8h.html#a1d15514e3f52654fcee15c36bffdabdd',1,'Tipos_PIG.h']]],
  ['infoeventomouse',['InfoEventoMouse',['../_tipos___p_i_g_8h.html#ae4776e7ba9ae98fb14a451daa8846806',1,'Tipos_PIG.h']]],
  ['infoeventoteclado',['InfoEventoTeclado',['../_tipos___p_i_g_8h.html#afa84a02f2ba9d3a9b667720e117912fe',1,'Tipos_PIG.h']]]
];
