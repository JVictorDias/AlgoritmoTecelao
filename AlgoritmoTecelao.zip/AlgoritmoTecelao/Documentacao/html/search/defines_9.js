var searchData=
[
  ['pig_5fcor',['PIG_Cor',['../_tipos___p_i_g_8h.html#a8b6f3eaa015f1c4bcf5a7cb192f88eac',1,'Tipos_PIG.h']]],
  ['pig_5festilo',['PIG_Estilo',['../_tipos___p_i_g_8h.html#adf9d904a68a18394d03e377b622e3ebd',1,'Tipos_PIG.h']]],
  ['pig_5fflip',['PIG_Flip',['../_tipos___p_i_g_8h.html#a6a7bbf7f383c0736345b7b1103834f33',1,'Tipos_PIG.h']]],
  ['pig_5fteclado',['PIG_Teclado',['../_tipos___p_i_g_8h.html#a7dbb446e84625585d0dd316c31769e3e',1,'Tipos_PIG.h']]],
  ['preto',['PRETO',['../_tipos___p_i_g_8h.html#a6483e93cde678c0a4b0c8059337d8e42',1,'Tipos_PIG.h']]],
  ['primeiro_5fcar',['PRIMEIRO_CAR',['../_tipos___p_i_g_8h.html#a90d5c0f5f78bb416e01152ec3a30d6ff',1,'Tipos_PIG.h']]]
];
