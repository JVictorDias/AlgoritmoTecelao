var searchData=
[
  ['tempodecorrido',['TempoDecorrido',['../_p_i_g_8h.html#a0564ea619f0f8aa25600b71071037ca1',1,'PIG.h']]],
  ['testacolisaoobjetos',['TestaColisaoObjetos',['../_p_i_g_8h.html#a7749778e8c64add36d453dfde6854000',1,'PIG.h']]]
];
