var struct_info_evento_teclado =
[
    [ "acao", "struct_info_evento_teclado.html#a296aa09c2b2b164ca1e58aff7394d7f3", null ],
    [ "inicio", "struct_info_evento_teclado.html#af4ba03b104f866071c02a882400c6121", null ],
    [ "repeticao", "struct_info_evento_teclado.html#a2ebbbeef2bac0adeef90b29b6274720f", null ],
    [ "tamanhoSelecao", "struct_info_evento_teclado.html#a1fa842c7b2fefe07ddb2f218899090d7", null ],
    [ "tecla", "struct_info_evento_teclado.html#a5cfdfb147bfd2edfcdafd26e66f4d587", null ],
    [ "texto", "struct_info_evento_teclado.html#a8e8399bcf714c54d73e9b4a9375d05e0", null ]
];