var struct_p_i_g___evento =
[
    [ "janela", "struct_p_i_g___evento.html#a608277842dd469ad6e578b3a3515e00a", null ],
    [ "mouse", "struct_p_i_g___evento.html#a57a0fd3f7878055ccbdc14e6092e1246", null ],
    [ "teclado", "struct_p_i_g___evento.html#a7657689fcc8188f0cf4c9f8e9c89f7d2", null ],
    [ "tipoEvento", "struct_p_i_g___evento.html#a0dd3cee5c6ca607a2beb6ff6fff44e81", null ]
];