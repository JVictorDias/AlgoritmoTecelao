var NAVTREE =
[
  [ "PIG 0.5.1", "index.html", [
    [ "Arquivos", null, [
      [ "Lista de Arquivos", "files.html", "files" ],
      [ "Membros dos Arquivos", "globals.html", [
        [ "Todos", "globals.html", null ],
        [ "Funções", "globals_func.html", null ],
        [ "Variáveis", "globals_vars.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_p_i_g_8h.html"
];

var SYNCONMSG = 'clique para desativar a sincronização do painel';
var SYNCOFFMSG = 'clique para ativar a sincronização do painel';