var annotated_dup =
[
    [ "InfoEventoJanela", "struct_info_evento_janela.html", "struct_info_evento_janela" ],
    [ "InfoEventoMouse", "struct_info_evento_mouse.html", "struct_info_evento_mouse" ],
    [ "InfoEventoTeclado", "struct_info_evento_teclado.html", "struct_info_evento_teclado" ],
    [ "PIG_Evento", "struct_p_i_g___evento.html", "struct_p_i_g___evento" ]
];